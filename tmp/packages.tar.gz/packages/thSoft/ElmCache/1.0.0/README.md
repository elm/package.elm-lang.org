Store your model in the cloud!

For an example application, see: https://github.com/thSoft/RemoteModel