# Sexp

Parses [S-expressions](https://en.wikipedia.org/wiki/S-expression).

## TODO

- [https://github.com/Dandandan/parser/issues/15]()
- Break up monolithic parser
- Pretty-print show (auto-indentation)
