# Char.Extra

Adds `isWhitespace` for Char.

## Testing

To run the tests: `cd tests && ./run-tests.sh`
