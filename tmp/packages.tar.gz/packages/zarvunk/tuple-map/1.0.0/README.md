# tuple-map

A little Elm library containing a few handy functions for mapping over pairs. There's really not much to it.
